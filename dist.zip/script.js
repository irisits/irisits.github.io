// ===========================================Animations============================================

function spin(){
    var spins = document.querySelectorAll(".spin");
    spins.forEach((event) => {
        event.classList.add("active");
    });
}

